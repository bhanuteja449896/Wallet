package com.example.db.service;


import com.example.db.entity.Wallet;
import com.example.db.repository.WalletRepository;
import com.example.db.vo.PayReq;
import com.example.db.vo.PayResponse;
import com.example.db.vo.WalletReq;
import com.example.db.vo.WalletResp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class WalletService {
    @Autowired
    WalletRepository walletRepository;

    public WalletResp WalletRegistraion(WalletReq req) {
        Wallet w=walletRepository.findByMobile(req.getMobile());

        if ( w != null){
            WalletResp walletResp = new WalletResp();
            walletResp.setRc("01");
            walletResp.setDesc("Wallet Already Registered");
            return walletResp;
        }
        else{
            w = new Wallet();
            w.setBalance(req.getBalance());
            w.setMobile(req.getMobile());
            w.setName(req.getName());
            walletRepository.save(w);
        }

        WalletResp walletResp = new WalletResp();
        walletResp.setRc("00");
        walletResp.setDesc("Success");
        return walletResp;
    }


    public String getBalanceByMobile(String mobile) {
        Wallet w=walletRepository.findByMobile(mobile);
        return w.getBalance();
    }

    public PayResponse reqPay(PayReq req) {
        Wallet w=walletRepository.findByMobile(req.getSendMobile());
        if(w!=null ){
            Integer debamount=Integer.valueOf( w.getBalance())-Integer.valueOf(req.getAmount());
            w.setBalance(String.valueOf(debamount));
            walletRepository.save(w);
            Wallet w1=walletRepository.findByMobile(req.getReceiveMobile());
                if(w1!=null){
                    Integer amount=Integer.valueOf( w1.getBalance())+Integer.valueOf(req.getAmount());
                    w1.setBalance(String.valueOf(amount));
                    walletRepository.save(w1);
                }
        }
        return new PayResponse();
    }
}
