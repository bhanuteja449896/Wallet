package com.example.db.vo;

public class PayResponse
{
    private String rc="00";
    private String des="success";

    public String getRc() {
        return rc;
    }

    public void setRc(String rc) {
        this.rc = rc;
    }

    public String getDes() {
        return des;
    }

    public void setDes(String des) {
        this.des = des;
    }
}
